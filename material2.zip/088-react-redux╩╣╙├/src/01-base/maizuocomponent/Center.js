/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */
import React, { Component } from 'react'

export default class Center extends Component {
    render() {
        return (
            <div>
                center组件
            </div>
        )
    }
}
