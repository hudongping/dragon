/*
 * @作者: kerwin
 * @公众号: 大前端私房菜
 */
function App(){
    return (
        <div>
            hello functional component
            <div>1111</div>
            <div>2222</div>
        </div>
    )
   
}

/*
  16.8之前  //无状态组件
  16.8之后  react hooks
*/
export default App